Open each .bbmodel directly in Blockbench (Java Block/Item project). Textures are embedded and supplied as PNG atlases. Pulley drum and door panels are separate named groups for later animation. Door is a one-block segment, intended to be repeated/assembled into a larger doorway. Controller and call button mount on the south wall; connector contact faces north. These are editable source assets only, not registered or animated in Minecraft. UVs use full 16x16 atlas tiles per face. Camouflage and all behavior require implementation in the mod.


Elevator rope: black cable, 2 x 2 pixels wide, one block long. Render dynamically from pulley to attachment, repeating texture along length. Do not place physical rope blocks. Java rendering and elevator mechanics are not included.
