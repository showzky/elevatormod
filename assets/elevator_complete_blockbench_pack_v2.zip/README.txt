Open each .bbmodel directly in Blockbench (Java Block/Item project). Textures are embedded and supplied as PNG atlases. Pulley drum and door panels are separate named groups for later animation.

UPDATED DOOR SETUP:
- The original small cabinet-like door has been replaced.
- The elevator door is now designed as a proper 2-block-tall, 2-block-wide entrance.
- Use these per-block door models for implementation:
  * elevator_door_lower_left.bbmodel
  * elevator_door_lower_right.bbmodel
  * elevator_door_upper_left.bbmodel
  * elevator_door_upper_right.bbmodel
- elevator_door.bbmodel is now a full 2x2 visual reference model showing the intended closed-door look.
- Keep the geometry simple and Minecraft-like. The individual panels are intentionally plain industrial steel, without overdesigned sci-fi detailing.
- The four door blocks should slide horizontally to open, with upper and lower parts moving together.

Controller and call button mount on the south wall; connector contact faces north. These are editable source assets only, not registered or animated in Minecraft. UVs use simple atlas regions and can be refined later. Camouflage and all behavior require implementation in the mod.

Elevator rope: black cable, 2 x 2 pixels wide, one block long. Render dynamically from pulley to attachment, repeating texture along length. Do not place physical rope blocks. Java rendering and elevator mechanics are not included.
