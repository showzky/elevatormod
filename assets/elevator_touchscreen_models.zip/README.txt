ELEVATOR TOUCHSCREENS — editable Blockbench Free Model source assets

1x1, 1x2 (wide x tall), 2x2. 16 model units per block. All use a 3-unit-deep wall-mounted housing. Rear is north (Z=0); screen faces south (+Z). Anchor is bottom-left as viewed from front (model x=0, y=0; account for facing in Java). Rotate to match placement.

Display glass area: X=2 to width-2, Y=2 to height-2, Z=3. Render live content slightly in front at Z=3.01 model units. Do not bake text/buttons into textures. Share one renderer and hit-coordinate mapping for all sizes. Large screens need multiblock placement, selection and break handling, one drop. No coplanar external faces. Use supplied PNGs and geometry, no mandatory animation dependency. Free format is intentional for full-size source models; convert to runtime renderer geometry or segmented models as appropriate.

Reuse existing Elevator Caller linking logic: 8-block horizontal range from a floor connector, no artificial vertical range limit. Do not change existing matching semantics. Support configurable Call, Destination and Information modes, live current floor/target/direction, direct clicks in world, scrolling where necessary; screens inside moving multiblocks must remain functional. Actual Java behavior is not included.
