Elevator floor discovery source review

This archive contains the complete current Java source tree, including supporting collision classes and the existing GameTest, plus project configuration and relevant blockstate metadata. Paths match the project. Files are copied without modification.

There is no ElevatorControllerBlockEntity.java or ElevatorControllerBlock.java: the registered controller uses FacingElevatorBlock. FloorConnectorBlock.java is the floor connector block implementation. ElevatorControlScreen, ElevatorControlMenu, ElevatorControlPayload and ElevatorClientInteraction implement the current GUI and network interactions. ElevatorCabinMotion.floors and ElevatorFloorDiscovery contain the two floor discovery paths.

Reported issue: an assembled elevator does not discover the stationary floor connector above it, preventing upward travel. No fix is included.
