package com.showzky.elevatormod;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.neoforge.network.PacketDistributor;

public final class ElevatorControlScreen extends AbstractContainerScreen<ElevatorControlMenu> {
 private EditBox name;
 private boolean nameLoaded;
 private int offset;
 private final Button[] floors=new Button[4];
 private Button assembly;
 public ElevatorControlScreen(ElevatorControlMenu menu,Inventory inv,Component title){super(menu,inv,title);imageWidth=216;imageHeight=menu.kind==1?146:218;}
 private void send(String action,CompoundTag data){PacketDistributor.sendToServer(new ElevatorControlPayload(menu.containerId,action,data));}
 @Override protected void init(){
  super.init();
  if(menu.kind==1){
   name=new EditBox(font,leftPos+12,topPos+50,192,20,Component.literal("Floor name"));name.setMaxLength(48);addRenderableWidget(name);
   addRenderableWidget(Button.builder(Component.literal("Save"),b->{CompoundTag t=new CompoundTag();t.putString("Name",name.getValue());send("name",t);}).bounds(leftPos+12,topPos+104,192,20).build());
  }else if(menu.kind==0){
   addRenderableWidget(new AbstractSliderButton(leftPos+34,topPos+86,170,20,Component.empty(),0.43){
    {updateMessage();}
    @Override protected void updateMessage(){setMessage(Component.literal(String.format(java.util.Locale.ROOT,"Speed: %.1f m/s",0.5+value*3.5)));}
    @Override protected void applyValue(){CompoundTag t=new CompoundTag();t.putDouble("Speed",(0.5+value*3.5)/20);send("speed",t);}
   });
   assembly=addRenderableWidget(Button.builder(Component.literal("Assemble"),b->send(menu.state.getBoolean("Active")?"disassemble":"assemble",new CompoundTag())).bounds(leftPos+12,topPos+178,192,20).build());
  }else{
   for(int i=0;i<4;i++){final int row=i;floors[i]=addRenderableWidget(Button.builder(Component.empty(),b->{ListTag list=menu.state.getList("Floors",10);int index=offset+row;if(index<list.size()){CompoundTag t=new CompoundTag();t.putInt("Y",list.getCompound(index).getInt("Y"));send("travel",t);}}).bounds(leftPos+12,topPos+98+i*25,192,22).build());}
  }
  addRenderableWidget(Button.builder(Component.literal("x"),b->onClose()).bounds(leftPos+imageWidth-24,topPos+6,18,18).build());
 }
 @Override protected void containerTick(){
  if(name!=null&&!nameLoaded&&menu.state.contains("Name")){name.setValue(menu.state.getString("Name"));nameLoaded=true;}
  if(assembly!=null)assembly.setMessage(Component.literal(menu.state.getBoolean("Active")?"Disassemble":"Assemble"));
  ListTag list=menu.state.getList("Floors",10);offset=Math.min(offset,Math.max(0,list.size()-4));
  for(int i=0;i<4;i++)if(floors[i]!=null){int index=offset+i;floors[i].visible=index<list.size();floors[i].active=menu.state.getBoolean("Active");if(index<list.size()){var f=list.getCompound(index);boolean current=Math.abs(menu.state.getDouble("Y")-f.getInt("Y"))<0.001;floors[i].setMessage(Component.literal((current?"> ":menu.state.getDouble("Target")==f.getInt("Y")?"* ":"")+f.getString("Name")));}}
 }
 @Override protected void renderBg(GuiGraphics g,float partial,int mx,int my){
  int x=leftPos,y=topPos;
  var texture=net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(ElevatorMod.MOD_ID,"textures/gui/"+(menu.kind==0?"pulley":menu.kind==1?"connector":"controller")+".png");
  g.blit(texture,x,y,0,0,imageWidth,imageHeight,imageWidth,imageHeight);
  if(menu.kind==1){text(g,"Floor name",12,38,0xff444444);text(g,"Height: Y "+menu.pos.getY(),12,80,0xff444444);text(g,menu.state.getBoolean("Connected")?"Connected":"Not connected",120,80,0xff267328);}
  else if(menu.kind==0){
   int stored=menu.state.getInt("Energy"),cap=Math.max(1,menu.state.getInt("Capacity"));g.fill(x+12,y+48,x+25,y+145,0xff444444);int fill=(int)(93L*stored/cap);g.fill(x+14,y+143-fill,x+23,y+143,0xffbe3434);
   text(g,stored+" / "+cap+" FE",34,52,0xff444444);text(g,menu.state.getBoolean("Active")?"Structure assembled":"Not assembled",34,120,0xff267328);text(g,menu.state.getString("Status"),34,138,0xff444444);
  }else{
   g.fill(x+12,y+39,x+204,y+89,0xff2e3831);text(g,"CURRENT FLOOR",19,46,0xffa8d39d);String current=menu.state.contains("Y")?"Between floors":"No cabin detected";
   for(Tag tag:menu.state.getList("Floors",10)){CompoundTag f=(CompoundTag)tag;if(Math.abs(f.getInt("Y")-menu.state.getDouble("Y"))<0.001)current=f.getString("Name");}
   text(g,current,19,60,0xffa8d39d);text(g,menu.state.getString("Status"),19,75,0xffa8d39d);
  }
 }
 private void text(GuiGraphics g,String s,int x,int y,int color){g.drawString(font,font.plainSubstrByWidth(s,imageWidth-x-12),leftPos+x,topPos+y,color,false);}
 @Override protected void renderLabels(GuiGraphics g,int mx,int my){g.drawString(font,title,12,12,0xff333333,false);}
 @Override public void render(GuiGraphics g,int mx,int my,float partial){super.render(g,mx,my,partial);renderTooltip(g,mx,my);}
 @Override public boolean mouseScrolled(double x,double y,double h,double v){if(menu.kind==2){offset=Math.max(0,Math.min(Math.max(0,menu.state.getList("Floors",10).size()-4),offset-(int)Math.signum(v)));return true;}return super.mouseScrolled(x,y,h,v);}
 @Override public boolean keyPressed(int key,int scan,int mods){if(name!=null&&name.isFocused()&&key!=256)return name.keyPressed(key,scan,mods);return super.keyPressed(key,scan,mods);}
}
