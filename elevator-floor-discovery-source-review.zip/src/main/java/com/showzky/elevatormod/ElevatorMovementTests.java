package com.showzky.elevatormod;
import net.minecraft.core.*;
import net.minecraft.gametest.framework.*;
import net.neoforged.neoforge.gametest.*;
@GameTestHolder(ElevatorMod.MOD_ID)
@PrefixGameTestTemplate(false)
public final class ElevatorMovementTests {
 @GameTest(template="empty",timeoutTicks=240)
 public static void roundTrip(GameTestHelper test){
  var level=test.getLevel();
  BlockPos pulleyPos=test.absolutePos(new BlockPos(3,9,3));
  BlockPos origin=test.absolutePos(new BlockPos(3,2,3));
  level.setBlock(pulleyPos,ElevatorRegistries.PULLEY.get().defaultBlockState(),3);
  level.setBlock(origin,ElevatorRegistries.ATTACHMENT.get().defaultBlockState(),3);
  level.setBlock(origin.below(),ElevatorRegistries.ELEVATOR_BLOCK.get().defaultBlockState(),3);
  level.setBlock(origin.below().south(),ElevatorRegistries.ELEVATOR_BLOCK.get().defaultBlockState(),3);
  level.setBlock(origin.south(2).below(),ElevatorRegistries.ELEVATOR_BLOCK.get().defaultBlockState(),3);
  level.setBlock(origin.south(2),ElevatorRegistries.ELEVATOR_BLOCK.get().defaultBlockState(),3);
  level.setBlock(origin.south(2).above(),ElevatorRegistries.ELEVATOR_BLOCK.get().defaultBlockState(),3);
  level.setBlock(origin.south(2).above(2),ElevatorRegistries.ELEVATOR_BLOCK.get().defaultBlockState(),3);
  level.setBlock(origin.south().above(2),ElevatorRegistries.ELEVATOR_BLOCK.get().defaultBlockState(),3);
  level.setBlock(origin.west(),ElevatorRegistries.CONTROLLER.get().defaultBlockState(),3);
  level.setBlock(origin.east(),ElevatorRegistries.FLOOR_CONNECTOR.get().defaultBlockState().setValue(FacingElevatorBlock.FACING,Direction.EAST),3);
  level.setBlock(origin.east(2),ElevatorRegistries.FLOOR_CONNECTOR.get().defaultBlockState().setValue(FacingElevatorBlock.FACING,Direction.WEST),3);
  level.setBlock(origin.east(2).above(3),ElevatorRegistries.FLOOR_CONNECTOR.get().defaultBlockState().setValue(FacingElevatorBlock.FACING,Direction.WEST),3);
  var pulley=(PoweredPulleyBlockEntity)level.getBlockEntity(pulleyPos);
  var scan=ElevatorAssembly.scan(level,pulleyPos);
  test.assertTrue(scan.attachment()!=null,"Stationary cabin must be detected");
  var discovered=ElevatorFloorDiscovery.discover(level,pulleyPos,scan.attachment(),scan.components());
  test.assertTrue(discovered.floors().size()==2,"Opposing connectors at two heights must be detected before assembly");
  test.assertTrue(discovered.floors().stream().anyMatch(f -> f.attachmentY()==origin.getY()),"Aligned connector must identify current floor");
  test.assertTrue(pulley.motion.assemble(),"Cabin must assemble");
  test.assertTrue(pulley.motion.floors().size()==2,"Both floors must remain detected after assembly");
  test.assertTrue(level.getBlockState(origin).isAir(),"Source blocks must transfer out of world");
  var collisionProbe=new net.minecraft.world.entity.decoration.ArmorStand(level,origin.getX()+0.5,origin.getY()+1,origin.getZ()+1.5);
  level.addFreshEntity(collisionProbe);
  collisionProbe.move(net.minecraft.world.entity.MoverType.SELF,new net.minecraft.world.phys.Vec3(0,-2,0));
  test.assertTrue(Math.abs(collisionProbe.getY()-origin.getY())<0.01,"Assembled platform must stop a falling entity, got "+collisionProbe.getY());
  collisionProbe.discard();
  var wallProbe=new net.minecraft.world.entity.decoration.ArmorStand(level,origin.getX()+0.5,origin.getY(),origin.getZ()+1.5);
  level.addFreshEntity(wallProbe);wallProbe.move(net.minecraft.world.entity.MoverType.SELF,new net.minecraft.world.phys.Vec3(0,0,1.5));
  test.assertTrue(wallProbe.getZ()<origin.getZ()+1.8,"Cabin wall must block horizontal movement");wallProbe.discard();
  var overlapProbe=new net.minecraft.world.entity.decoration.ArmorStand(level,origin.getX()+0.5,origin.getY(),origin.getZ()+1.9);
  level.addFreshEntity(overlapProbe);
  ElevatorContraptionCollision.resolve(pulley.motion,level,pulley.motion.y,pulley.motion.y);
  test.assertTrue(overlapProbe.getBoundingBox().maxZ<=origin.getZ()+2.001,"Create collision pass must separate an entity overlapping the wall; z="+overlapProbe.getZ());
  overlapProbe.discard();
  var ceilingProbe=new net.minecraft.world.entity.decoration.ArmorStand(level,origin.getX()+0.5,origin.getY(),origin.getZ()+1.5);
  level.addFreshEntity(ceilingProbe);double startY=ceilingProbe.getY();ceilingProbe.move(net.minecraft.world.entity.MoverType.SELF,new net.minecraft.world.phys.Vec3(0,1,0));
  test.assertTrue(ceilingProbe.getY()<startY+0.5,"Cabin ceiling must block upward movement");ceilingProbe.discard();
  var rider=new net.minecraft.world.entity.decoration.ArmorStand(level,origin.getX()+0.5,origin.getY(),origin.getZ()+1.5);level.addFreshEntity(rider);
  pulley.energy().receiveEnergy(10000,false);pulley.motion.request(origin.getY()+3);
  test.runAfterDelay(15,()->{
   double before=pulley.motion.y;
   var movingWallProbe=new net.minecraft.world.entity.decoration.ArmorStand(level,origin.getX()+0.5,before,origin.getZ()+1.5);
   level.addFreshEntity(movingWallProbe);movingWallProbe.move(net.minecraft.world.entity.MoverType.SELF,new net.minecraft.world.phys.Vec3(0,0,1.5));
   test.assertTrue(movingWallProbe.getZ()<origin.getZ()+1.8,"Moving cabin wall must block movement");movingWallProbe.discard();
   var movingCeilingProbe=new net.minecraft.world.entity.decoration.ArmorStand(level,origin.getX()+0.5,before,origin.getZ()+1.5);
   level.addFreshEntity(movingCeilingProbe);movingCeilingProbe.move(net.minecraft.world.entity.MoverType.SELF,new net.minecraft.world.phys.Vec3(0,1,0));
   test.assertTrue(movingCeilingProbe.getY()<before+0.5,"Moving cabin ceiling must block movement");movingCeilingProbe.discard();
   pulley.consume(100000);
   test.runAfterDelay(4,()->{
    test.assertTrue(Math.abs(before-pulley.motion.y)<0.001,"Power loss must hold cabin");
    var saved=new net.minecraft.nbt.CompoundTag();pulley.motion.save(saved);pulley.motion.load(saved);
    test.assertTrue(pulley.motion.active(),"Serialized cabin must retain blocks");
    pulley.energy().receiveEnergy(10000,false);
   });
  });
  test.runAfterDelay(80,()->{
   test.assertTrue(Math.abs(pulley.motion.y-origin.getY()-3)<0.001,"Cabin must reach upper connector: "+pulley.motion.status+" y="+pulley.motion.y);
   test.assertTrue(Math.abs(rider.getY()-origin.getY()-3)<0.2,"Standing entity must travel with floor: "+rider.getY());
   pulley.motion.request(origin.getY());
  });
  test.runAfterDelay(160,()->{
   test.assertTrue(Math.abs(pulley.motion.y-origin.getY())<0.001,"Cabin must return to lower connector");
   var fakePlayer=net.neoforged.neoforge.common.util.FakePlayerFactory.getMinecraft(level);
   level.setBlock(origin,net.minecraft.world.level.block.Blocks.STONE.defaultBlockState(),3);
   var blockedBreak=new net.neoforged.neoforge.event.level.BlockEvent.BreakEvent(level,pulleyPos,level.getBlockState(pulleyPos),fakePlayer);
   PulleyBreakProtection.onBreak(blockedBreak);
   test.assertTrue(blockedBreak.isCanceled() && pulley.motion.active(),"Blocked restoration must cancel pulley breaking and retain cabin");
   level.removeBlock(origin,false);
   var safeBreak=new net.neoforged.neoforge.event.level.BlockEvent.BreakEvent(level,pulleyPos,level.getBlockState(pulleyPos),fakePlayer);
   PulleyBreakProtection.onBreak(safeBreak);
   test.assertTrue(!safeBreak.isCanceled() && !pulley.motion.active(),"Safe pulley break must restore cabin first");
   level.destroyBlock(pulleyPos,false);
   test.assertTrue(level.getBlockState(origin).is(ElevatorRegistries.ATTACHMENT),"Attachment must restore");
   test.assertTrue(level.getBlockState(origin.below()).is(ElevatorRegistries.ELEVATOR_BLOCK),"Platform must restore");
   test.succeed();
  });
 }
}
